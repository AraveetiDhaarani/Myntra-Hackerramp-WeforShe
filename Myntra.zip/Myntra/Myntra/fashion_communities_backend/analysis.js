async function analyzeAndStoreResultsByStyle(style) {
    try {
        // Perform analysis to find top posts by style
        const result = await InstagramPost.aggregate([
            { $match: { hashtags: `#${style}` } }, // Match posts with the specified style
            { $sort: {  likes: -1 } }, // Sort by createdAt descending and likes descending
            { $limit: 10 } // Limit to top 10 posts per style
        ]);

        // Store results in a new collection for the style
        const TrendyPost = mongoose.model(`${style}Post`, InstagramPostSchema);
        await TrendyPost.insertMany(result);
        console.log(`Stored trendy ${style} posts successfully.`);
    } catch (err) {
        console.error(`Error analyzing and storing ${style} posts:`, err);
    }
}

// Example usage: Perform analysis for each style and store results
async function main() {
    try {
        // Define styles to analyze and store
        const stylesToAnalyze = ['Bohemian', 'Minimalist', /* Add more styles as needed */];

        // Perform analysis and store results for each style
        for (const style of stylesToAnalyze) {
            await analyzeAndStoreResultsByStyle(style);
        }
    } catch (err) {
        console.error('Main function error:', err);
    } finally {
        mongoose.disconnect();
    }
}

// Run the main function
main();
