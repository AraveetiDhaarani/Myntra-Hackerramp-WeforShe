const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const InstagramPost = require('./models/InstagramPost');

const app = express();
const port = 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/fashion_communities', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    //useFindAndModify: false  // To suppress deprecation warnings
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

// Middleware
app.use(bodyParser.json());

// Function to perform analysis and store trendy posts by style
async function analyzeAndStoreResultsByStyle(style) {
    try {
        // Perform analysis to find top posts by style
        const result = await InstagramPost.aggregate([
            { $match: { hashtags: new RegExp(`#${style}`, 'i') } }, // Match posts with the specified style
            { $sort: { createdAt: -1, likes: -1 } }, // Sort by createdAt descending and likes descending
            { $limit: 10 } // Limit to top 10 posts per style
        ]);

        // Store results in a new collection for the style
        const TrendyPost = mongoose.model(`${style}Post`, InstagramPost.schema);
        await TrendyPost.deleteMany({}); // Clear existing data (optional)
        await TrendyPost.create(result); // Insert new trendy posts
        console.log(`Stored trendy ${style} posts successfully.`);
    } catch (err) {
        console.error(`Error analyzing and storing ${style} posts:`, err);
    }
}

// Define styles to analyze periodically
const stylesToAnalyze = ['Bohemian', 'Minimalist','Streetstyle','Retro']; // Add more styles as needed

// Interval for periodic analysis (every 1 second)
const analysisInterval = 20000; // in milliseconds (1 second)

// Perform initial analysis and start periodic analysis
async function startPeriodicAnalysis() {
    try {
        // Perform initial analysis for all styles
        for (const style of stylesToAnalyze) {
            await analyzeAndStoreResultsByStyle(style);
        }

        // Set interval for periodic analysis
        setInterval(async () => {
            for (const style of stylesToAnalyze) {
                await analyzeAndStoreResultsByStyle(style);
            }
        }, analysisInterval);

        console.log(`Periodic analysis started. Interval: ${analysisInterval / 1000} seconds`);
    } catch (err) {
        console.error('Error starting periodic analysis:', err);
    }
}

// Start periodic analysis
startPeriodicAnalysis();

// API endpoint to fetch Bohemian community data
app.get('/api/bohemian', async (req, res) => {
    try {
        const TrendyBohemianPost = mongoose.model('BohemianPost', InstagramPost.schema);
        const bohemianPosts = await TrendyBohemianPost.find({});
        console.log(bohemianPosts)
        res.json(bohemianPosts);
    } catch (err) {
        console.error('Error fetching Bohemian community data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// API endpoint to fetch Minimalist community data
app.get('/api/minimalist', async (req, res) => {
    try {
        const TrendyMinimalistPost = mongoose.model('MinimalistPost', InstagramPost.schema);
        const minimalistPosts = await TrendyMinimalistPost.find({});
        res.json(minimalistPosts);
    } catch (err) {
        console.error('Error fetching Minimalist community data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
app.get('/api/streetstyle', async (req, res) => {
    try {
        const TrendyStreetStylePost = mongoose.model('StreetStylePost', InstagramPost.schema);
        const StreetStyelPost = await TrendyStreetStylePost.find({});
        res.json(StreetStyelPost);
    } catch (err) {
        console.error('Error fetching StreetStyle community data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
app.get('/api/retro', async (req, res) => {
    try {
        const TrendyRetroPost = mongoose.model('RetroPost', InstagramPost.schema);
        const RetroPosts = await TrendyRetroPost.find({});
        res.json(RetroPosts);
    } catch (err) {
        console.error('Error fetching Retro community data:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
const frontendPath = path.join(__dirname, '../frontend');

// Middleware
app.use(express.static(frontendPath)); // Serve static files from frontend directory

// API endpoints and other routes
// Define your API endpoints and other routes here

// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(frontendPath, 'index.html'));
});
// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});
